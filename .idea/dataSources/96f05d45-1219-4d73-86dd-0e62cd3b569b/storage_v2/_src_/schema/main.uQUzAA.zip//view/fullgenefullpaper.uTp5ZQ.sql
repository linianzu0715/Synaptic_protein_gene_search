CREATE VIEW FullGenefullPaper AS SELECT p.GeneID,l.Name AS Localisation,  MGI,HumanEntrez,MouseEntrez,HumanName, MouseName,PaperPMID,a.Name AS Paper, a.Year AS Year, SpeciesTaxID,MethodID FROM Gene  g join PaperGene p on g.ID=p.GeneID  join Localisation l on l.ID = p.LocalisationID  join Paper a on a.PMID = p.PaperPMID;

