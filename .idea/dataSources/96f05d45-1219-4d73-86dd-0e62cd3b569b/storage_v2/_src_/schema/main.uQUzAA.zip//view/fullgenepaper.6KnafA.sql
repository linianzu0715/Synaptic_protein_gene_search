CREATE VIEW FullGenePaper AS SELECT p.GeneID,LocalisationID, MGI,HumanEntrez,MouseEntrez,HumanName,MouseName,PaperPMID,SpeciesTaxID,MethodID FROM Gene  g join PaperGene p on g.ID=p.GeneID;

