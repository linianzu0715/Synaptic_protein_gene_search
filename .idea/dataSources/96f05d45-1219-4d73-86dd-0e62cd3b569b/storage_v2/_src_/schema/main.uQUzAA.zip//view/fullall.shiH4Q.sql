CREATE VIEW FullAll AS SELECT  p.GeneID AS GeneID,
        l.Name AS Compartment,  
        HumanEntrez,
        HumanName,
        MouseEntrez,
        MouseName,
        RatEntrez,
        RatName,
        PaperPMID AS PMID,
        a.Year AS Year, 
        a.Name AS Paper, 
        b.Name AS Brain_Region,
        D.Description AS Disease,
        S.Name AS Species,
        M.Name AS Method
FROM  Gene g join PaperGene p on g.ID=p.GeneID  
             join Localisation l on l.ID = p.LocalisationID  
             join Paper a on a.PMID = p.PaperPMID
             join BrainRegion b on p.BrainRegionID = b.ID
             join DiseaseGene DG on DG.GeneID = g.ID
             join Disease D on D.HDOID = DG.HDOID
             join Species S on S.TaxID = p.SpeciesTaxID
             join Method M on M.ID = p.MethodID;

